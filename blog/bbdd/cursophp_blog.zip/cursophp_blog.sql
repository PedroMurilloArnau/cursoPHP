-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.4.22-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.3.0.6589
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para cursophp_blog
CREATE DATABASE IF NOT EXISTS `cursophp_blog` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `cursophp_blog`;

-- Volcando estructura para tabla cursophp_blog.articulos
CREATE TABLE IF NOT EXISTS `articulos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(100) NOT NULL,
  `extracto` varchar(300) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `texto` text NOT NULL,
  `thumb` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

-- Volcando datos para la tabla cursophp_blog.articulos: ~4 rows (aproximadamente)
INSERT INTO `articulos` (`id`, `titulo`, `extracto`, `fecha`, `texto`, `thumb`) VALUES
	(1, 'Primer Articulo', 'Articulo ciudad', '2023-01-16 17:54:17', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam ut eros efficitur, interdum mi vel, iaculis augue. Praesent efficitur mollis augue, et venenatis eros consectetur nec. Sed ac tellus neque. Aenean aliquam massa a lectus porttitor fringilla. Aenean elit dolor, finibus quis maximus at, pulvinar ut odio. Duis facilisis euismod libero eu molestie. Quisque faucibus interdum lacus quis tempus. Pellentesque et molestie ipsum.', '1.png'),
	(2, 'Segundo Articulo', 'Articulo sobre paisajes', '2023-01-16 17:54:21', ' Duis magna tortor, varius vel velit nec, blandit vehicula dolor. Fusce venenatis vitae lacus at pharetra. Donec consequat, nulla in interdum ornare, mi lorem iaculis erat, vitae semper orci nunc a sapien. Proin finibus nisl turpis. Pellentesque sed mi tellus. Vestibulum rhoncus turpis a sapien sodales pulvinar. Aenean sed ipsum vehicula, ornare sem quis, mollis dolor. Phasellus sit amet cursus tellus.', '2.png'),
	(3, 'Tercer Articulo', 'Articulo sobre Fuji', '2023-01-16 17:55:02', 'Curabitur vehicula tortor sed sapien congue, sed viverra dui accumsan. Nullam dictum in felis et mollis. Suspendisse in feugiat urna. Integer consectetur metus sem, a tempus felis viverra vel. Quisque molestie dictum fermentum. Vivamus ac neque a diam pretium suscipit sed in purus. Quisque sodales neque sed lorem posuere,', '3.png'),
	(4, 'Cuarto Articulo', 'Paisaje Tori', '2023-01-16 17:55:52', 'Quisque ultricies egestas volutpat. Cras nec sapien et nunc auctor elementum eget ac tortor. Curabitur tincidunt, nulla in vulputate malesuada, quam nunc rutrum nisi, sit amet congue ante massa non eros. Pellentesque interdum consequat odio, sed scelerisque purus hendrerit a. Ut laoreet lacinia nulla, id placerat leo. Aenean nec accumsan nisi. Duis aliquam lacinia neque, quis bibendum lacus feugiat a. Aliquam convallis convallis justo, sed pharetra sem dignissim ac.', '4.png');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
